console.log('<----- Injected script started running ----->');

/*******SUBTOTAL START********/			
window.Subtotal_price='';
window.subtotal=0;

window.Discount_price='';
window.discount=0;

window.watch_activated=false;

window.subtotal_updater = function (findtext){

    function trimChar(r,t){for(;r.charAt(0)==t;)r=r.substring(1);for(;r.charAt(r.length-1)==t;)r=r.substring(0,r.length-1);return r}

    jQuery('div:contains("Sub Total")').find('*:contains("Sub Total"):visible').each(function(i,e){
        if(jQuery(e).contents().filter(function(){return this.nodeType == 3;}).first().text().toLowerCase().includes("Sub Total".toLowerCase(n))){
                jQuery(e).text('subtotal');
        }
    });

    jQuery('div:contains("'+findtext+'")').find('*:contains("'+findtext+'"):visible').each(function(i,e){
        if(jQuery(e).contents().filter(function(){return this.nodeType == 3;}).first().text().toLowerCase().includes(findtext.toLowerCase())){
            var relative_parent=jQuery(e).closest('*:contains("$")').first();
            //console.log(relative_parent)
            if(relative_parent.length ){
                var target_text_els=relative_parent.find('*:contains("$")');
                if(target_text_els.length)
                    var target_text=target_text_els.first().text().trim();
                else
                    var target_text=relative_parent.text().trim();

                target_text=trimChar(target_text,'$');
                if(target_text.includes('$'))
                    {Subtotal_price= target_text.slice(0, target_text.indexOf('$'));}
                else
                    {Subtotal_price=target_text;}
                Subtotal_price=jQuery.trim(Subtotal_price);
            }
            if(Subtotal_price != ''){
                Subtotal_price=Subtotal_price.replace('USD','');
            }
            Subtotal_price = jQuery.trim(Subtotal_price);

            var char_reg = /[a-zA-Z]/g;                    
            if(!char_reg.test(Subtotal_price) && Subtotal_price != ''){
                window.subtotal = Subtotal_price.replace(/[^0-9\.]+/g,"");

                jQuery('div:contains("discount")').find('*:contains("discount"):visible').each(function(i,e){
                    if(jQuery(e).contents().filter(function(){return this.nodeType == 3;}).first().text().toLowerCase().includes("discount".toLowerCase())){
                        var relative_parent_dis=jQuery(e).next('*:contains("$")').first();

                        if(relative_parent_dis.length ){

                            var target_text_dis_els=relative_parent_dis.find('*:contains("$")');
                            if(target_text_dis_els.length)
                                var target_text_dis=target_text_dis_els.first().text().trim();
                            else
                                var target_text_dis=relative_parent_dis.text().trim();

                            target_text_dis=jQuery.trim(target_text_dis);
                            target_text_dis=trimChar(target_text_dis,'-');
                            target_text_dis=jQuery.trim(target_text_dis);
                            target_text_dis=trimChar(target_text_dis,'$');
                            target_text_dis=jQuery.trim(target_text_dis);
                            target_text_dis=trimChar(target_text_dis,'-');
                            target_text_dis=jQuery.trim(target_text_dis);
                            target_text_dis=trimChar(target_text_dis,'$');
                            target_text_dis=jQuery.trim(target_text_dis);
                            target_text_dis=trimChar(target_text_dis,'-');
                            
                            if(target_text_dis.includes('$'))
                                {Discount_price= target_text_dis.slice(0, target_text_dis.indexOf('$'));}
                            else
                                {Discount_price=target_text_dis;}
                            Discount_price=jQuery.trim(Discount_price);
                        }
                        if(Discount_price != ''){
                            Discount_price=Discount_price.replace('USD','');
                        }
                        Discount_price = jQuery.trim(Discount_price);

                        var char_reg = /[a-zA-Z]/g;                    
                        if(!char_reg.test(Discount_price) && Discount_price != ''){
                            window.discount = Discount_price.replace(/[^0-9\.]+/g,"");
                        }
                    }
                });
                window.setCartData();
                console.log(window.subtotal+','+window.discount);
                return false;
            }
        }
    });
}

// if("undefined" == typeof jQuery)
// {
//     var jq = document.createElement("script");jq.src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js?fdfg=sd", document.getElementsByTagName("head")[0].appendChild(jq);
// }
// var jqryinvl = setInterval(function() { if("undefined" != typeof jQuery) { clearInterval(jqryinvl);

    jQuery.expr[':'].contains = function(a, i, m) { 
      return jQuery(a).text().toUpperCase().indexOf(m[3].toUpperCase()) >= 0; 
    };
    
    window.subtotal_updater('subtotal');
    if (window.subtotal==0)
        window.subtotal_updater('total before tax');
    

    (function() {
        var origOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function() {
            this.addEventListener('load', function() {
                window.watch_activated=true;
            });
            origOpen.apply(this, arguments);
        };
    })();


    setInterval(function(){
        if (window.watch_activated) {
            window.subtotal_updater('subtotal');
            if (window.subtotal==0)
                window.subtotal_updater('total before tax');
            window.watch_activated=false;
        }
    },3000);

// }},200);
/*******SUBTOTAL END********/